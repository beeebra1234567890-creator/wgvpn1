package com.example.wgclient

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PointMode
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------- Палитра (почти чёрный фон + фиолетовый акцент) ----------
val Bg = Color(0xFF050507)
val NavBg = Color(0xFF0C0C10)
val Accent = Color(0xFF8250F5)
val AccentLight = Color(0xFFA98BFF)
val AccentDeep = Color(0xFF5B2BC9)
val Surface1 = Color(0xFF111114)
val Surface2 = Color(0xFF1B1B20)
val LineC = Color(0xFF232329)
val Muted = Color(0xFF8E8E99)
val Good = Color(0xFF3DDC5A)
val Warn = Color(0xFFFFC857)
val Bad = Color(0xFFFF5C6C)

// ---------- Карта мира из точек ----------
private fun poly(vararg v: Int): List<Pair<Float, Float>> =
    List(v.size / 2) { v[it * 2].toFloat() to v[it * 2 + 1].toFloat() } // (lon, lat)

private val LAND: List<List<Pair<Float, Float>>> = listOf(
    // Северная Америка
    poly(-168, 66, -160, 71, -140, 70, -120, 70, -95, 72, -80, 70, -62, 60, -55, 52, -66, 45, -70, 42, -76, 35,
        -81, 30, -80, 25, -84, 30, -90, 29, -97, 26, -97, 20, -90, 21, -87, 21, -83, 10, -78, 8, -80, 8, -86, 12,
        -92, 15, -105, 20, -110, 24, -115, 30, -118, 34, -124, 40, -124, 48, -135, 58, -148, 60, -158, 57, -165, 60),
    // Южная Америка
    poly(-78, 8, -72, 12, -62, 10, -52, 5, -50, 0, -35, -6, -39, -14, -48, -26, -58, -35, -65, -42, -68, -52,
        -73, -50, -73, -38, -71, -20, -76, -14, -81, -5, -80, 0, -77, 4),
    // Гренландия
    poly(-55, 60, -45, 60, -20, 70, -20, 80, -60, 82, -72, 78, -58, 70),
    // Европа
    poly(-10, 36, -9, 43, -2, 44, -5, 48, 2, 51, 8, 54, 10, 58, 5, 62, 15, 69, 28, 71, 40, 67, 40, 60, 30, 55,
        40, 48, 30, 45, 28, 41, 24, 38, 20, 40, 14, 45, 18, 40, 12, 38, 5, 43, -2, 37),
    // Африка
    poly(-17, 21, -10, 30, -6, 36, 10, 37, 20, 33, 32, 31, 35, 28, 43, 12, 51, 12, 40, -3, 40, -15, 35, -25,
        27, -34, 18, -34, 12, -17, 9, -1, 9, 4, -8, 4, -17, 14),
    // Азия
    poly(40, 60, 60, 70, 80, 73, 110, 77, 140, 72, 170, 68, 165, 60, 155, 55, 140, 52, 135, 43, 128, 38, 122, 40,
        120, 30, 110, 20, 106, 10, 100, 8, 104, 1, 98, 16, 92, 22, 80, 15, 77, 8, 72, 20, 67, 25, 57, 25, 52, 28,
        48, 30, 56, 17, 43, 13, 35, 28, 36, 36, 28, 41, 30, 45, 40, 48),
    // Япония
    poly(130, 31, 135, 34, 141, 40, 142, 45, 138, 38),
    // Австралия
    poly(114, -22, 122, -18, 130, -12, 137, -12, 142, -11, 146, -19, 153, -26, 150, -37, 141, -38, 135, -34, 115, -34),
)

/** Города-«маячки» (lon, lat). */
private val CITIES = listOf(
    -100f to 40f, -70f to -12f, 10f to 50f, 22f to 45f, 37f to 55f, 105f to 35f,
    120f to 25f, 139f to 36f, 150f to -27f, 55f to 25f, 75f to 22f,
)

private fun inside(x: Float, y: Float, p: List<Pair<Float, Float>>): Boolean {
    var c = false
    var j = p.size - 1
    for (i in p.indices) {
        val (xi, yi) = p[i]
        val (xj, yj) = p[j]
        if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c
        j = i
    }
    return c
}

/** Нормализованные (0..1) координаты точек суши. Считается один раз. */
private fun landDots(): List<Offset> {
    val out = ArrayList<Offset>()
    var lat = 83f
    while (lat > -58f) {
        var lon = -178f
        while (lon < 180f) {
            if (LAND.any { inside(lon, lat, it) }) out.add(Offset((lon + 180f) / 360f, (85f - lat) / 145f))
            lon += 3.2f
        }
        lat -= 3.2f
    }
    return out
}

@Composable
fun WorldMap(modifier: Modifier = Modifier) {
    val dots = remember { landDots() }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawPoints(
            dots.map { Offset(it.x * w, it.y * h) }, PointMode.Points,
            Color(0xFF26262D), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round
        )
        for ((lon, lat) in CITIES) {
            val p = Offset((lon + 180f) / 360f * w, (85f - lat) / 145f * h)
            drawCircle(Accent.copy(alpha = 0.18f), radius = 7.dp.toPx(), center = p)
            drawCircle(Accent, radius = 2.5.dp.toPx(), center = p)
        }
    }
}

// ---------- Кнопка питания ----------
@Composable
fun PowerButton(state: VpnState, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "power")
    val spin = transition.animateFloat(
        0f, 360f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "spin"
    )
    val pulse = transition.animateFloat(
        0.55f, 1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    Box(
        modifier
            .size(176.dp)
            .clip(CircleShape)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f
            val ringR = r * 0.74f
            val ringW = 5.dp.toPx()
            // внешний диск + тонкая обводка
            drawCircle(Color(0xFF09090C), radius = r, center = c)
            drawCircle(Color(0xFF2A2A31), radius = r - 0.5.dp.toPx(), center = c, style = Stroke(1.dp.toPx()))
            // свечение
            val glowA = when (state) {
                VpnState.CONNECTED -> 0.10f * pulse.value
                VpnState.DISCONNECTED -> 0.07f
                VpnState.CONNECTING -> 0.03f
            }
            for (k in 4 downTo 1) {
                drawCircle(
                    Accent.copy(alpha = (glowA * (5 - k)).coerceAtMost(1f)), radius = ringR, center = c,
                    style = Stroke(ringW + k * 5.dp.toPx())
                )
            }
            when (state) {
                VpnState.CONNECTED -> drawCircle(
                    Brush.radialGradient(listOf(AccentLight, Accent, AccentDeep), center = c, radius = ringR + ringW / 2),
                    radius = ringR + ringW / 2, center = c
                )
                VpnState.CONNECTING -> {
                    drawCircle(Accent.copy(alpha = 0.25f), radius = ringR, center = c, style = Stroke(ringW))
                    drawCircle(Color(0xFF0E0E12), radius = ringR - ringW / 2, center = c)
                    rotate(spin.value, c) {
                        drawArc(
                            Accent, startAngle = 0f, sweepAngle = 110f, useCenter = false,
                            topLeft = Offset(c.x - ringR, c.y - ringR), size = Size(ringR * 2, ringR * 2),
                            style = Stroke(ringW, cap = StrokeCap.Round)
                        )
                    }
                }
                VpnState.DISCONNECTED -> {
                    drawCircle(
                        Brush.sweepGradient(listOf(AccentLight, Accent, AccentDeep, Accent, AccentLight), center = c),
                        radius = ringR, center = c, style = Stroke(ringW)
                    )
                    drawCircle(Color(0xFF0E0E12), radius = ringR - ringW / 2, center = c)
                }
            }
        }
        PowerIcon(if (state == VpnState.CONNECTING) AccentLight else Color.White, Modifier.size(46.dp))
    }
}

@Composable
fun PowerIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val stroke = Stroke(width = w * 0.085f, cap = StrokeCap.Round)
        drawArc(
            color, startAngle = -60f, sweepAngle = 300f, useCenter = false,
            topLeft = Offset(w * 0.17f, w * 0.2f), size = Size(w * 0.66f, w * 0.66f), style = stroke
        )
        drawLine(color, Offset(w * 0.5f, w * 0.08f), Offset(w * 0.5f, w * 0.46f), strokeWidth = stroke.width, cap = StrokeCap.Round)
    }
}

// ---------- Иконки ----------

/** Логотип: щит с замком. */
@Composable
fun ShieldLogo(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val shield = Path().apply {
            moveTo(w * .5f, w * .04f)
            lineTo(w * .92f, w * .18f)
            lineTo(w * .92f, w * .5f)
            cubicTo(w * .92f, w * .76f, w * .72f, w * .92f, w * .5f, w * .98f)
            cubicTo(w * .28f, w * .92f, w * .08f, w * .76f, w * .08f, w * .5f)
            lineTo(w * .08f, w * .18f)
            close()
        }
        drawPath(shield, Color(0xFF160D2B))
        drawPath(shield, Accent, style = Stroke(w * .06f, join = StrokeJoin.Round))
        // дужка замка
        drawArc(
            Accent, startAngle = 180f, sweepAngle = 180f, useCenter = false,
            topLeft = Offset(w * .38f, w * .27f), size = Size(w * .24f, w * .26f),
            style = Stroke(w * .06f, cap = StrokeCap.Round)
        )
        // корпус замка
        drawRoundRect(Accent, Offset(w * .32f, w * .42f), Size(w * .36f, w * .3f), CornerRadius(w * .05f))
        // замочная скважина
        drawCircle(Color(0xFF160D2B), w * .04f, Offset(w * .5f, w * .54f))
        drawRect(Color(0xFF160D2B), Offset(w * .48f, w * .54f), Size(w * .04f, w * .1f))
    }
}

@Composable
fun GearIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val c = center
        val sw = w * .09f
        drawCircle(color, w * .27f, c, style = Stroke(sw))
        drawCircle(color, w * .1f, c, style = Stroke(sw))
        for (k in 0 until 8) {
            val a = (k * PI / 4).toFloat()
            val dx = cos(a); val dy = sin(a)
            drawLine(
                color, Offset(c.x + dx * w * .31f, c.y + dy * w * .31f),
                Offset(c.x + dx * w * .43f, c.y + dy * w * .43f), strokeWidth = w * .13f, cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun BoltIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val p = Path().apply {
            moveTo(w * .6f, w * .05f); lineTo(w * .2f, w * .55f); lineTo(w * .47f, w * .55f)
            lineTo(w * .38f, w * .95f); lineTo(w * .8f, w * .4f); lineTo(w * .54f, w * .4f); close()
        }
        drawPath(p, color)
        drawPath(p, color, style = Stroke(w * .06f, join = StrokeJoin.Round))
    }
}

/** Стрелка загрузки (вниз, с полкой) или отдачи (вверх, с полкой). */
@Composable
fun ArrowIcon(down: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val sw = w * .09f
        fun y(v: Float) = w * (if (down) v else 1f - v)
        drawLine(color, Offset(w * .5f, y(.1f)), Offset(w * .5f, y(.72f)), sw, StrokeCap.Round)
        val head = Path().apply { moveTo(w * .26f, y(.5f)); lineTo(w * .5f, y(.74f)); lineTo(w * .74f, y(.5f)) }
        drawPath(head, color, style = Stroke(sw, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawLine(color, Offset(w * .2f, y(.9f)), Offset(w * .8f, y(.9f)), sw, StrokeCap.Round)
    }
}

@Composable
fun ShieldCheckIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val shield = Path().apply {
            moveTo(w * .5f, w * .06f)
            lineTo(w * .9f, w * .2f)
            lineTo(w * .9f, w * .5f)
            cubicTo(w * .9f, w * .75f, w * .7f, w * .9f, w * .5f, w * .96f)
            cubicTo(w * .3f, w * .9f, w * .1f, w * .75f, w * .1f, w * .5f)
            lineTo(w * .1f, w * .2f)
            close()
        }
        drawPath(shield, color, style = Stroke(w * .07f, join = StrokeJoin.Round))
        val tick = Path().apply { moveTo(w * .32f, w * .5f); lineTo(w * .46f, w * .64f); lineTo(w * .7f, w * .38f) }
        drawPath(tick, color, style = Stroke(w * .08f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
fun ChevronIcon(down: Boolean, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val p = Path().apply {
            if (down) { moveTo(w * .22f, w * .36f); lineTo(w * .5f, w * .64f); lineTo(w * .78f, w * .36f) }
            else { moveTo(w * .36f, w * .22f); lineTo(w * .64f, w * .5f); lineTo(w * .36f, w * .78f) }
        }
        drawPath(p, color, style = Stroke(w * .09f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** Треугольник «play» или квадрат «stop». */
@Composable
fun PlayIcon(stop: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        if (stop) {
            drawRoundRect(Color.White, Offset(w * .2f, w * .2f), Size(w * .6f, w * .6f), CornerRadius(w * .1f))
        } else {
            val p = Path().apply { moveTo(w * .26f, w * .14f); lineTo(w * .88f, w * .5f); lineTo(w * .26f, w * .86f); close() }
            drawPath(p, Color.White)
            drawPath(p, Color.White, style = Stroke(w * .1f, join = StrokeJoin.Round))
        }
    }
}

@Composable
fun NavIcon(kind: Int, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        when (kind) {
            0 -> { // дом
                val p = Path().apply {
                    moveTo(w * .5f, w * .1f); lineTo(w * .9f, w * .46f); lineTo(w * .8f, w * .46f)
                    lineTo(w * .8f, w * .88f); lineTo(w * .2f, w * .88f); lineTo(w * .2f, w * .46f)
                    lineTo(w * .1f, w * .46f); close()
                }
                drawPath(p, color)
                drawPath(p, color, style = Stroke(w * .06f, join = StrokeJoin.Round))
                drawRoundRect(NavBg, Offset(w * .42f, w * .58f), Size(w * .16f, w * .3f), CornerRadius(w * .04f))
            }
            1 -> { // столбики статистики
                val r = CornerRadius(w * .04f)
                drawRoundRect(color, Offset(w * .12f, w * .56f), Size(w * .2f, w * .34f), r)
                drawRoundRect(color, Offset(w * .4f, w * .3f), Size(w * .2f, w * .6f), r)
                drawRoundRect(color, Offset(w * .68f, w * .1f), Size(w * .2f, w * .8f), r)
            }
            else -> { // сетка 2×2
                val r = CornerRadius(w * .08f)
                val s = Size(w * .34f, w * .34f)
                drawRoundRect(color, Offset(w * .1f, w * .1f), s, r)
                drawRoundRect(color, Offset(w * .56f, w * .1f), s, r)
                drawRoundRect(color, Offset(w * .1f, w * .56f), s, r)
                drawRoundRect(color, Offset(w * .56f, w * .56f), s, r)
            }
        }
    }
}

/** Вертикальные столбики качества связи. */
@Composable
fun PingBars(ping: Int?, modifier: Modifier = Modifier) {
    val level = when {
        ping == null -> 0
        ping < 120 -> 4
        ping < 250 -> 3
        ping < 450 -> 2
        else -> 1
    }
    val col = when (level) { 4, 3 -> Good; 2 -> Warn; 1 -> Bad; else -> Muted }
    Canvas(modifier) {
        val bw = size.width / 7f
        for (i in 0 until 4) {
            val h = size.height * (0.4f + 0.2f * i)
            drawRoundRect(
                if (i < level) col else Color(0xFF3A3A3A),
                Offset(i * bw * 1.7f, size.height - h), Size(bw, h),
                CornerRadius(bw / 2)
            )
        }
    }
}

/** Заливка-«спарклайн» для экрана статистики. */
fun DrawScope.sparkline(values: List<Long>, color: Color) {
    if (values.size < 2) return
    val max = (values.maxOrNull() ?: 1L).coerceAtLeast(1L).toFloat()
    val step = size.width / (values.size - 1)
    val line = Path()
    val fill = Path()
    values.forEachIndexed { i, v ->
        val x = i * step
        val y = size.height - (v / max) * size.height * 0.9f - 2f
        if (i == 0) { line.moveTo(x, y); fill.moveTo(x, size.height); fill.lineTo(x, y) } else { line.lineTo(x, y); fill.lineTo(x, y) }
    }
    fill.lineTo(size.width, size.height); fill.close()
    drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = .35f), Color.Transparent)))
    drawPath(line, color, style = Stroke(2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
}
